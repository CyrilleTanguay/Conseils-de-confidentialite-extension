# LISEZ-MOI
CoSeCo est une extension qui permet de donner des conseils de sécurité et de confidentialité à son utilisateur.
## FAQ
* Q: Vous proposez l'installation d'extensions. Êtes-vous sponsorisé?
* R: Je ne suis et ne serai JAMAIS sponsorisé. Si je vous recommande d'installer certaines extensions, c'est parce que mon extension elle-même n'est pas conçue pour vous protéger des virus.

* Q: C'est moi, ou cette extension me semble incomplète/contient des bogues?
* R: Pour le moment, il manque des éléments, car j'ai développé cette extension dans le cadre de mon projet de fin d'études au collège, ce qui fait que je n'ai pas eu le temps de tout mettre. Des améliorations viendront.

## LICENCES DES ICÔNES:
IcoMoon - Free: GPL / CC-BY 4.0 (créé par Keyamoon. La couleur et la taille ont été modifiées.)
Brands: CC0 1.0
IcoMoon Font Awesome:  SIL OFL 1.1 License
Lien regroupant les icônes: https://icomoon.io/app/#/select/library


